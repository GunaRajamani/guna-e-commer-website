import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useTheme } from '../context/ThemeContext'
import ProductCard from '../components/ProductCard'
import ProductGallery from '../components/ProductGallery'

function ProductDetail() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [relatedProducts, setRelatedProducts] = useState([])
  const [quantity, setQuantity] = useState(1)
  const { addToCart } = useCart()
  const { colors, isDark } = useTheme()

  useEffect(() => {
    fetch(`https://fakestoreapi.com/products/${id}`)
      .then((res) => res.json())
      .then((data) => setProduct(data))

    fetch('https://fakestoreapi.com/products')
      .then((res) => res.json())
      .then((data) => {
        fetch(`https://fakestoreapi.com/products/${id}`)
          .then((res) => res.json())
          .then((mainProduct) => {
            const related = data.filter(
              (p) => p.category === mainProduct.category && p.id !== mainProduct.id
            )
            setRelatedProducts(related.slice(0, 4))
          })
      })
  }, [id])

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product)
    }
    alert(`Added ${quantity} item(s) to cart!`)
    setQuantity(1)
  }

  if (!product) {
    return <div style={{ textAlign: 'center', padding: '40px', color: colors.text }}>Loading...</div>
  }

  // Create array of product images (FakeStore API has single image)
  const productImages = [product.image, product.image, product.image, product.image]

  return (
    <>
      <style>{`
        .pd-container {
          max-width: 1280px;
          margin: 0 auto;
          padding: 40px 5%;
          background: ${colors.bg};
          color: ${colors.text};
          min-height: 100vh;
          transition: all 0.3s ease;
        }

        .pd-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 60px;
          margin-bottom: 60px;
        }

        .pd-info h1 {
          font-size: 32px;
          font-weight: 800;
          margin-bottom: 12px;
        }

        .pd-category {
          display: inline-block;
          padding: 6px 14px;
          background: ${colors.primary}22;
          color: ${colors.primary};
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          margin-bottom: 16px;
        }

        .pd-price {
          font-size: 28px;
          font-weight: 800;
          color: ${colors.primary};
          margin: 20px 0;
        }

        .pd-rating {
          font-size: 14px;
          color: #f59e0b;
          margin-bottom: 20px;
        }

        .pd-desc {
          color: ${colors.textSecondary};
          line-height: 1.8;
          margin-bottom: 28px;
        }

        .pd-quantity {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 20px;
        }

        .pd-qty-btn {
          width: 36px;
          height: 36px;
          border: 1px solid ${colors.border};
          border-radius: 8px;
          background: ${colors.bgSecondary};
          color: ${colors.text};
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s;
        }

        .pd-qty-btn:hover {
          background: ${colors.hover};
        }

        .pd-qty-input {
          width: 60px;
          text-align: center;
          border: 1px solid ${colors.border};
          border-radius: 8px;
          padding: 8px;
          background: ${colors.bgSecondary};
          color: ${colors.text};
        }

        .pd-btn {
          padding: 14px 32px;
          border-radius: 12px;
          background: linear-gradient(135deg, ${colors.primary}, #2563eb);
          color: #fff;
          border: none;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
        }

        .pd-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px ${isDark ? 'rgba(0,220,255,0.3)' : 'rgba(59,130,246,0.3)'};
        }

        .pd-related h2 {
          font-size: 24px;
          font-weight: 800;
          margin-bottom: 24px;
        }

        .pd-grid-related {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
        }

        @media (max-width: 768px) {
          .pd-grid {
            grid-template-columns: 1fr;
            gap: 30px;
          }

          .pd-info h1 {
            font-size: 24px;
          }
        }
      `}</style>

      <div className="pd-container">
        {/* Product Detail */}
        <div className="pd-grid">
          {/* Gallery */}
          <div>
            <ProductGallery images={productImages} />
          </div>

          {/* Info */}
          <div className="pd-info">
            <span className="pd-category">{product.category}</span>
            <h1>{product.title}</h1>
            <div className="pd-rating">⭐ {product.rating?.rate || 4.5} ({product.rating?.count || 100} reviews)</div>
            <p className="pd-price">${product.price}</p>
            <p className="pd-desc">{product.description}</p>

            <div className="pd-quantity">
              <button className="pd-qty-btn" onClick={() => setQuantity(Math.max(1, quantity - 1))}>−</button>
              <input type="number" className="pd-qty-input" value={quantity} onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} />
              <button className="pd-qty-btn" onClick={() => setQuantity(quantity + 1)}>+</button>
            </div>

            <button className="pd-btn" onClick={handleAddToCart}>
              Add {quantity} to Cart
            </button>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="pd-related">
            <h2>More from {product.category}</h2>
            <div className="pd-grid-related">
              {relatedProducts.map((p) => (
                <div key={p.id}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  )
}

export default ProductDetail
