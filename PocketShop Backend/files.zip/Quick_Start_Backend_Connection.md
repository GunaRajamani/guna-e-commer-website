# QUICK START: Connect Frontend to Backend (5 Minutes)

## Fastest Way to Get Started

### **Step 1: Install Backend (2 min)**

```bash
mkdir pocketshop-backend
cd pocketshop-backend
npm init -y
npm install express cors dotenv
```

### **Step 2: Create Backend Server (1 min)**

**File: server.js**

```javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Temporary in-memory products (replace with database later)
const products = [
  { id: 1, title: 'Laptop', price: 999, category: 'electronics', description: 'High-end laptop', image: 'url' },
  { id: 2, title: 'Phone', price: 599, category: 'electronics', description: 'Smartphone', image: 'url' },
  { id: 3, title: 'Shirt', price: 29, category: 'clothing', description: 'Cotton shirt', image: 'url' },
];

// API Routes
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  res.json(product || { error: 'Not found' });
});

app.post('/api/products', (req, res) => {
  const newProduct = { id: products.length + 1, ...req.body };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`✅ Backend running on http://localhost:${PORT}`));
```

**File: .env**

```
PORT=5000
```

### **Step 3: Run Backend (30 sec)**

```bash
node server.js
# Output: ✅ Backend running on http://localhost:5000
```

---

## Update Frontend (2 min)

### **Step 4: Create API Service**

**File: src/services/api.js**

```javascript
const API_URL = 'http://localhost:5000/api';

export async function getProducts() {
  const res = await fetch(`${API_URL}/products`);
  return res.json();
}

export async function getProductById(id) {
  const res = await fetch(`${API_URL}/products/${id}`);
  return res.json();
}
```

### **Step 5: Update ProductsGrid Component**

**In src/components/ProductsGrid.jsx, replace the fetch call:**

```javascript
// OLD (line 15-30)
useEffect(() => {
  const fetchProducts = async () => {
    try {
      const response = await fetch('https://fakestoreapi.com/products')
      // ...
    }
  }
  fetchProducts()
}, [])

// NEW (replace with)
import { getProducts } from '../services/api'

useEffect(() => {
  const fetchProducts = async () => {
    try {
      const data = await getProducts()
      setProducts(data)
      setFilteredProducts(data)
      setLoading(false)
    } catch (error) {
      console.error('Error:', error)
      setLoading(false)
    }
  }
  fetchProducts()
}, [])
```

### **Step 6: Run Frontend**

```bash
npm run dev
# Products should load from backend now!
```

---

## Test It

1. **Backend running?** → `http://localhost:5000/api/products` ✅
2. **Frontend running?** → `http://localhost:5176` ✅
3. **Products loading?** → Check browser console for products ✅

---

## Next: Add Database

```bash
npm install mongoose
```

Replace in-memory `products` array with MongoDB:

```javascript
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/pocketshop');

const productSchema = new mongoose.Schema({
  title: String,
  price: Number,
  category: String,
  description: String,
  image: String,
});

const Product = mongoose.model('Product', productSchema);

app.get('/api/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});
```

---

## Environment Variables

Create `backend/.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/pocketshop
```

Create `frontend/.env`:
```
VITE_API_URL=http://localhost:5000/api
```

Use in frontend:
```javascript
const API_URL = import.meta.env.VITE_API_URL;
```

---

## Deployment Checklist

**Before deploying:**

1. ✅ Backend: Change `http://localhost:5000` to production URL
2. ✅ Frontend: Set `.env.production` with backend URL
3. ✅ Backend: Deploy to Render/Railway/Heroku
4. ✅ Frontend: Deploy to Vercel/Netlify

---

## That's It! 🎉

You now have:
- ✅ Backend server running
- ✅ Frontend fetching from backend
- ✅ API endpoints ready
- ✅ Foundation for real app

Next steps: Add database, authentication, payments!

