import { useTheme } from '../context/ThemeContext'

export default function ThemeToggle() {
  const { isDark, toggleTheme, colors } = useTheme()

  return (
    <>
      <style>{`
        .theme-toggle {
          position: relative;
          width: 52px;
          height: 28px;
          border-radius: 14px;
          background: ${colors.border};
          border: none;
          cursor: pointer;
          padding: 2px;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
        }

        .theme-toggle:hover {
          background: ${colors.hover};
        }

        .toggle-circle {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: ${colors.primary};
          transition: transform 0.3s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
        }

        .toggle-circle.dark {
          transform: translateX(24px);
        }

        .toggle-icon {
          font-size: 14px;
        }
      `}</style>

      <button 
        className="theme-toggle" 
        onClick={toggleTheme}
        title={isDark ? "Light mode" : "Dark mode"}
      >
        <div className={`toggle-circle ${isDark ? 'dark' : ''}`}>
          <span className="toggle-icon">
            {isDark ? '☀️' : '🌙'}
          </span>
        </div>
      </button>
    </>
  )
}
