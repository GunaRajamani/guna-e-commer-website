# HOW TO CONNECT FRONTEND TO BACKEND

## Overview

Your React app currently uses **FakeStore API** (fake data). To use real data, you need:

1. **Backend Server** (Node.js, Python, Java, etc.)
2. **Database** (MongoDB, PostgreSQL, MySQL, etc.)
3. **API Endpoints** (Routes that return data)
4. **Authentication** (User login/registration)

---

## Step 1: Choose Your Backend Stack

### **Option A: Node.js + Express (Recommended for Beginners)**

```bash
mkdir pocketshop-backend
cd pocketshop-backend
npm init -y
npm install express cors dotenv mongoose bcryptjs jsonwebtoken
```

### **Option B: Python + Flask**
```bash
mkdir pocketshop-backend
cd pocketshop-backend
pip install flask flask-cors pymongo python-dotenv
```

### **Option C: Use Firebase (Easiest, No Backend Setup)**
No backend coding needed! Firebase handles everything.

---

## Step 2A: Backend Setup (Node.js + Express)

### **File: backend/server.js**

```javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();
const mongoose = require('mongoose');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.log('❌ MongoDB error:', err));

// Product Schema
const productSchema = new mongoose.Schema({
  id: Number,
  title: String,
  price: Number,
  description: String,
  category: String,
  image: String,
  rating: Number,
  reviews: Number,
});

const Product = mongoose.model('Product', productSchema);

// API ENDPOINTS

// 1. GET all products
app.get('/api/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 2. GET product by ID
app.get('/api/products/:id', async (req, res) => {
  try {
    const product = await Product.findOne({ id: req.params.id });
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 3. POST create product (admin only)
app.post('/api/products', async (req, res) => {
  try {
    const newProduct = new Product(req.body);
    const saved = await newProduct.save();
    res.status(201).json(saved);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// 4. PUT update product
app.put('/api/products/:id', async (req, res) => {
  try {
    const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// 5. DELETE product
app.delete('/api/products/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product deleted' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
```

### **File: backend/.env**

```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/pocketshop
PORT=5000
JWT_SECRET=your_secret_key_here
```

### **Run Backend:**

```bash
node server.js
# Output: 🚀 Server running on port 5000
```

---

## Step 3: Update Frontend to Call Backend

### **Option 1: Using Fetch API**

**File: src/services/productService.js**

```javascript
const API_URL = 'http://localhost:5000/api';

// GET all products
export async function getProducts() {
  try {
    const response = await fetch(`${API_URL}/products`);
    if (!response.ok) throw new Error('Failed to fetch products');
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    return [];
  }
}

// GET single product
export async function getProductById(id) {
  try {
    const response = await fetch(`${API_URL}/products/${id}`);
    if (!response.ok) throw new Error('Product not found');
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    return null;
  }
}

// ADD product (admin)
export async function addProduct(productData) {
  try {
    const response = await fetch(`${API_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(productData),
    });
    if (!response.ok) throw new Error('Failed to add product');
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    return null;
  }
}

// DELETE product
export async function deleteProduct(id) {
  try {
    const response = await fetch(`${API_URL}/products/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete product');
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    return null;
  }
}
```

### **Option 2: Using Axios (Better)**

```bash
npm install axios
```

**File: src/services/productService.js**

```javascript
import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api',
});

export const getProducts = () => API.get('/products').then(res => res.data);
export const getProductById = (id) => API.get(`/products/${id}`).then(res => res.data);
export const addProduct = (data) => API.post('/products', data).then(res => res.data);
export const deleteProduct = (id) => API.delete(`/products/${id}`).then(res => res.data);
export const updateProduct = (id, data) => API.put(`/products/${id}`, data).then(res => res.data);
```

---

## Step 4: Update ProductsGrid Component

**File: src/components/ProductsGrid.jsx**

```javascript
import { useState, useEffect } from 'react'
import ProductCard from './ProductCard'
import { getProducts } from '../services/productService'

function ProductsGrid() {
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState('featured')

  // Fetch from backend instead of FakeStore
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts()
        setProducts(data)
        setFilteredProducts(data)
        setLoading(false)
      } catch (error) {
        console.error('Error fetching products:', error)
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  // Filter and sort (same as before)
  useEffect(() => {
    let filtered = products

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((p) => p.category === selectedCategory)
    }

    if (searchQuery) {
      filtered = filtered.filter((p) =>
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }

    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price)
        break
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price)
        break
      case 'newest':
        filtered.reverse()
        break
      default:
        break
    }

    setFilteredProducts(filtered)
  }, [selectedCategory, searchQuery, sortBy, products])

  const categories = ['all', ...new Set(products.map((p) => p.category))]

  return (
    // ... rest of component (same as before)
  )
}

export default ProductsGrid
```

---

## Step 5: Add Environment Variables

**File: .env** (Frontend)

```
VITE_API_URL=http://localhost:5000/api
```

**Update productService.js:**

```javascript
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
```

---

## Step 6: Add User Authentication

### **Backend: User Routes**

```javascript
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// User Schema
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  phone: String,
  addresses: Array,
});

const User = mongoose.model('User', userSchema);

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
    });
    
    await newUser.save();
    
    // Create JWT token
    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET);
    
    res.status(201).json({ token, user: { id: newUser._id, name, email } });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ error: 'User not found' });
    
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ error: 'Invalid password' });
    
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
    
    res.json({ token, user: { id: user._id, name: user.name, email } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

### **Frontend: Auth Service**

```javascript
// src/services/authService.js

export async function register(name, email, password) {
  const response = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  });
  const data = await response.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
  }
  return data;
}

export async function login(email, password) {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const data = await response.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
  }
  return data;
}

export function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
}

export function getToken() {
  return localStorage.getItem('token');
}

export function getUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}
```

---

## Step 7: Add Orders to Backend

```javascript
// Order Schema
const orderSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  products: Array,
  subtotal: Number,
  tax: Number,
  shipping: Number,
  total: Number,
  status: { type: String, default: 'Pending' },
  createdAt: { type: Date, default: Date.now },
});

const Order = mongoose.model('Order', orderSchema);

// Create Order
app.post('/api/orders', async (req, res) => {
  try {
    const { userId, products, subtotal, tax, shipping, total } = req.body;
    
    const newOrder = new Order({
      userId,
      products,
      subtotal,
      tax,
      shipping,
      total,
      status: 'Processing',
    });
    
    const saved = await newOrder.save();
    res.status(201).json(saved);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get User Orders
app.get('/api/orders/:userId', async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.params.userId });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

## Step 8: Deploy Backend

### **Option 1: Heroku (Free tier deprecated, use Render)**

```bash
npm install -g render-cli
render deploy
```

### **Option 2: Render.com (Recommended)**

1. Go to https://render.com
2. Create new Web Service
3. Connect your GitHub
4. Set environment variables
5. Deploy!

### **Option 3: Railway.app**

```bash
npm install -g @railway/cli
railway link
railway up
```

---

## Step 9: Update Frontend API URL for Production

**File: .env.production**

```
VITE_API_URL=https://your-backend-url.onrender.com/api
```

---

## Complete Folder Structure

```
pocketshop-project/
├── frontend/
│   ├── src/
│   │   ├── services/
│   │   │   ├── productService.js
│   │   │   └── authService.js
│   │   ├── components/
│   │   ├── pages/
│   │   └── ...
│   ├── .env
│   └── .env.production
│
└── backend/
    ├── models/
    │   ├── Product.js
    │   ├── User.js
    │   └── Order.js
    ├── routes/
    │   ├── products.js
    │   ├── users.js
    │   ├── auth.js
    │   └── orders.js
    ├── server.js
    ├── .env
    └── package.json
```

---

## Testing Your Connection

### **1. Start Backend:**
```bash
cd backend
node server.js
```

### **2. Start Frontend:**
```bash
cd frontend
npm run dev
```

### **3. Test API with Postman:**
- GET: `http://localhost:5000/api/products`
- POST: `http://localhost:5000/api/auth/login`

### **4. Check Browser Console:**
Should see products loading from backend!

---

## Common Issues & Fixes

| Issue | Solution |
|-------|----------|
| CORS Error | Add `cors` package to backend |
| Cannot connect | Check backend running on port 5000 |
| 404 errors | Check API routes in backend |
| MongoDB error | Add correct connection string in .env |
| Token not working | Check JWT_SECRET in .env |

---

## Next Steps

✅ Set up Node.js + Express backend
✅ Connect MongoDB database
✅ Create API endpoints for products
✅ Add user authentication
✅ Implement order system
✅ Add payment gateway (Stripe)
✅ Deploy frontend & backend
✅ Set up CI/CD pipeline

---

## Resources

- **Node.js & Express:** https://expressjs.com/
- **MongoDB:** https://www.mongodb.com/
- **JWT Auth:** https://jwt.io/
- **Render Hosting:** https://render.com/
- **Stripe Payments:** https://stripe.com/

