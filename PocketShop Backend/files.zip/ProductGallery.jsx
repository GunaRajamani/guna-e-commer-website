import { useState } from 'react'
import { useTheme } from '../context/ThemeContext'

export default function ProductGallery({ images = [] }) {
  const { colors } = useTheme()
  const [activeIndex, setActiveIndex] = useState(0)

  // Use provided images or fallback to placeholder
  const galleryImages = images.length > 0 
    ? images 
    : Array(4).fill('https://via.placeholder.com/400')

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + galleryImages.length) % galleryImages.length)
  }

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % galleryImages.length)
  }

  return (
    <>
      <style>{`
        .gallery-root {
          display: grid;
          grid-template-columns: 1fr 100px;
          gap: 16px;
          max-width: 500px;
        }

        .gallery-main {
          position: relative;
          background: ${colors.bgSecondary};
          border-radius: 12px;
          overflow: hidden;
          aspect-ratio: 1;
          border: 1px solid ${colors.border};
        }

        .gallery-image {
          width: 100%;
          height: 100%;
          object-fit: contain;
          padding: 12px;
        }

        .gallery-nav {
          position: absolute;
          bottom: 16px;
          left: 50%;
          transform: translateX(-50%);
          display: flex;
          gap: 8px;
          z-index: 2;
        }

        .gallery-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: rgba(255,255,255,0.4);
          border: none;
          cursor: pointer;
          transition: all 0.3s;
        }

        .gallery-dot.active {
          background: #fff;
          width: 24px;
          border-radius: 4px;
        }

        .gallery-arrow {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: rgba(0,0,0,0.4);
          border: none;
          color: #fff;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s;
          z-index: 1;
        }

        .gallery-arrow:hover {
          background: rgba(0,0,0,0.6);
          transform: translateY(-50%) scale(1.1);
        }

        .gallery-arrow-left { left: 12px; }
        .gallery-arrow-right { right: 12px; }

        .gallery-counter {
          position: absolute;
          top: 12px;
          right: 12px;
          background: rgba(0,0,0,0.5);
          color: #fff;
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          z-index: 1;
        }

        .gallery-thumbs {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .gallery-thumb {
          width: 100%;
          aspect-ratio: 1;
          border-radius: 8px;
          border: 2px solid ${colors.border};
          background: ${colors.bgSecondary};
          cursor: pointer;
          overflow: hidden;
          transition: all 0.3s;
          padding: 4px;
        }

        .gallery-thumb:hover {
          border-color: ${colors.primary};
        }

        .gallery-thumb.active {
          border-color: ${colors.primary};
          box-shadow: 0 0 0 2px ${colors.primary};
        }

        .gallery-thumb-img {
          width: 100%;
          height: 100%;
          object-fit: contain;
        }

        @media (max-width: 768px) {
          .gallery-root {
            grid-template-columns: 1fr;
            max-width: 100%;
          }

          .gallery-thumbs {
            flex-direction: row;
            overflow-x: auto;
          }

          .gallery-thumb {
            flex-shrink: 0;
            width: 80px;
            height: 80px;
          }

          .gallery-arrow {
            width: 36px;
            height: 36px;
          }

          .gallery-arrow-left { left: 8px; }
          .gallery-arrow-right { right: 8px; }
        }
      `}</style>

      <div className="gallery-root">
        {/* Main Image */}
        <div className="gallery-main">
          <img
            src={galleryImages[activeIndex]}
            alt={`Product ${activeIndex + 1}`}
            className="gallery-image"
          />

          {/* Arrows */}
          {galleryImages.length > 1 && (
            <>
              <button className="gallery-arrow gallery-arrow-left" onClick={handlePrev}>‹</button>
              <button className="gallery-arrow gallery-arrow-right" onClick={handleNext}>›</button>
            </>
          )}

          {/* Counter */}
          <div className="gallery-counter">
            {activeIndex + 1} / {galleryImages.length}
          </div>

          {/* Dots */}
          {galleryImages.length > 1 && (
            <div className="gallery-nav">
              {galleryImages.map((_, i) => (
                <button
                  key={i}
                  className={`gallery-dot ${i === activeIndex ? 'active' : ''}`}
                  onClick={() => setActiveIndex(i)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Thumbnails */}
        {galleryImages.length > 1 && (
          <div className="gallery-thumbs">
            {galleryImages.map((img, i) => (
              <button
                key={i}
                className={`gallery-thumb ${i === activeIndex ? 'active' : ''}`}
                onClick={() => setActiveIndex(i)}
              >
                <img src={img} alt={`Thumbnail ${i + 1}`} className="gallery-thumb-img" />
              </button>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
