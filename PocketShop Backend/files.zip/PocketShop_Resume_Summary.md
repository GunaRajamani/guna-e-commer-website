# POCKETSHOP - E-COMMERCE WEBSITE

## Project Overview
Full-stack e-commerce web application featuring dynamic product catalog, shopping cart system, and user profile management. Built with React and modern web technologies.

---

## Technologies Used
**Frontend:** React 18, Vite, React Router DOM  
**State Management:** React Context API (CartContext)  
**Styling:** CSS3, Tailwind CSS, Bootstrap  
**API Integration:** FakeStore REST API  
**Storage:** Browser LocalStorage  
**Build Tool:** Vite

---

## Key Features Implemented

### 1. **Product Catalog & Discovery**
- Fetches 20+ products from FakeStore API dynamically
- Advanced search functionality with real-time filtering
- Category filtering (Electronics, Clothing, Jewelry, Books)
- Sort by price (low-high, high-low) and newest items
- Responsive product grid (auto-fill layout)
- Product cards with images, titles, descriptions, and prices

### 2. **Shopping Cart System**
- Add/Remove products from cart with real-time updates
- Cart badge displaying item count
- Quantity controls with increment/decrement buttons
- Automatic subtotal, tax (18% GST), and shipping calculation
- FREE shipping threshold (over ₹500)
- Cart persistence using React Context
- Order summary panel with checkout button

### 3. **User Profile Dashboard**
- 4-tab interface: Profile, Addresses, Orders, Settings
- Profile management (edit name, email, phone)
- Multiple address management (Home, Office)
- Order history with status tracking
- Notification settings and password management
- Logout and account deletion options

### 4. **Navigation & Routing**
- Sticky navigation bar with logo and menu links
- Cart icon with badge notification
- Profile link for user access
- 7 pages with React Router (Home, Products, Cart, Profile, Login, About, Contact)
- Responsive mobile navigation

### 5. **Design & UX**
- Light-mode responsive design
- Blue color scheme (#3b82f6 primary color)
- Mobile-first approach
- Smooth animations and transitions
- Loading spinners for async operations
- Empty state messages

---

## Technical Skills Demonstrated

✅ **React Concepts:**
- Functional components and hooks (useState, useEffect, useContext)
- Context API for global state management
- Component composition and reusability
- Conditional rendering and list rendering

✅ **JavaScript:**
- ES6+ syntax (arrow functions, destructuring, spread operator)
- Array methods (map, filter, sort, reduce)
- Async/await for API calls
- Event handling and form management

✅ **Web Development:**
- REST API integration and data fetching
- CSS Grid and Flexbox layouts
- Responsive design (mobile, tablet, desktop)
- LocalStorage for data persistence
- Component styling with inline CSS

✅ **Problem Solving:**
- Dynamic filtering and sorting logic
- Price calculation with tax and shipping
- Category management from API data
- Loading states and error handling

---

## Project Metrics

- **Components Created:** 10+ reusable React components
- **Pages Built:** 7 fully functional pages
- **API Integration:** Real-time product fetching from external API
- **State Management:** Centralized cart and product state
- **Responsive Breakpoints:** Mobile (480px), Tablet (768px), Desktop (1200px)
- **Product Count:** 20+ items with dynamic filtering

---

## What I Learned

1. Building scalable React applications with Context API
2. Integrating third-party REST APIs
3. Managing complex state and data flow
4. Creating responsive and user-friendly interfaces
5. Implementing e-commerce core functionalities
6. Code organization and component structure
7. Browser storage and data persistence

---

## How to Run

```bash
cd PocketShop
npm install
npm run dev
# Runs on http://localhost:5176/
```

---

## Future Enhancements

- Dark mode toggle
- User authentication (JWT)
- Payment gateway integration (Stripe/Razorpay)
- Backend API and database
- Order tracking system
- Product reviews and ratings
- Wishlist functionality

---

## Project Structure

```
src/
├── context/
│   └── CartContext.jsx (State management)
├── components/
│   ├── Navbar.jsx
│   ├── ProductCard.jsx
│   ├── ProductsGrid.jsx
│   ├── Footer.jsx
│   └── BannerCarousel.jsx
├── pages/
│   ├── Home.jsx
│   ├── Cart.jsx
│   ├── ProductDetail.jsx
│   ├── ProfileDashboard.jsx
│   ├── Login.jsx
│   ├── About.jsx
│   └── Contact.jsx
└── App.jsx
```

---

## GitHub Repository
[Add your GitHub link here]

---

## Live Demo
[Add your deployed link here - Vercel/Netlify]

