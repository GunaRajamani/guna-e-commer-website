# POCKETSHOP - E-COMMERCE WEB APPLICATION

## Quick Summary (For Resume Bullet Points)

**PocketShop** | React | JavaScript | Context API | REST API  
*Full-stack e-commerce web application built with React and Vite*

---

## Resume Bullet Points (Copy-Paste These)

• Developed a fully functional e-commerce web application using React, featuring dynamic product catalog, shopping cart, and user profile management

• Integrated FakeStore REST API to fetch and display 20+ products with real-time search, filtering, and sorting capabilities

• Implemented shopping cart system using React Context API with add/remove functionality, quantity controls, and automatic price calculations (subtotal, 18% tax, shipping)

• Built responsive user interface with CSS Grid/Flexbox, supporting mobile (480px), tablet (768px), and desktop (1200px) layouts

• Created 7 pages with React Router navigation including Home, Products, Cart, Profile, Login, About, and Contact pages

• Designed 4-tab profile dashboard with user information management, address management, order history, and settings

• Utilized React hooks (useState, useEffect, useContext) for state management and component lifecycle handling

• Implemented data persistence using browser LocalStorage for cart and user preferences

• Demonstrated proficiency in ES6+ JavaScript, component composition, and async API integration

---

## Skills Showcased

**Languages:** JavaScript (ES6+), HTML5, CSS3  
**Libraries/Frameworks:** React 18, React Router DOM, Vite  
**Concepts:** Context API, Functional Components, Hooks, REST API Integration  
**Styling:** CSS Grid, Flexbox, Responsive Design  
**Tools:** Vite, npm, Git  

---

## Quick Stats

✅ 10+ React Components  
✅ 7 Pages with Routing  
✅ 20+ Products from API  
✅ Real-time Search & Filter  
✅ Cart Management System  
✅ Mobile Responsive Design  

---

## How to Present in Interview

**"I built PocketShop, a full-featured e-commerce website using React. The application fetches products from an external API, allows users to browse with advanced search and filtering, manage their shopping cart with real-time calculations, and access a personalized profile dashboard. I used React Context for state management, React Router for navigation, and CSS Grid/Flexbox for responsive design across all devices."**

