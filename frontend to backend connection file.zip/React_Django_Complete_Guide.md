# REACT + DJANGO: Complete Integration Guide

## Architecture Overview

```
React Frontend (http://localhost:5173)
         ↓ (API Calls)
Django REST API (http://localhost:8000/api/)
         ↓ (Database Queries)
PostgreSQL/MySQL Database
```

---

## Part 1: Django Backend Setup

### **Step 1: Install Django & Required Packages**

```bash
mkdir pocketshop-backend
cd pocketshop-backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install packages
pip install django djangorestframework django-cors-headers python-decouple

# Create Django project
django-admin startproject pocketshop .

# Create Django app
python manage.py startapp products
python manage.py startapp users
python manage.py startapp orders
```

---

### **Step 2: Configure Django Settings**

**File: pocketshop/settings.py**

```python
# Add to INSTALLED_APPS
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'products',
    'users',
    'orders',
]

# Add CORS Middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',  # ADD THIS
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# CORS Settings (Allow React frontend)
CORS_ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://localhost:3000",
    "http://127.0.0.1:5173",
]

# REST Framework Settings
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 10
}

# Database (PostgreSQL recommended)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'pocketshop',
        'USER': 'postgres',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}

# Or use SQLite (development)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# JWT Settings
from datetime import timedelta

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=24),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
}
```

---

### **Step 3: Create Django Models**

**File: products/models.py**

```python
from django.db import models

class Product(models.Model):
    CATEGORY_CHOICES = (
        ('electronics', 'Electronics'),
        ('clothing', 'Clothing'),
        ('books', 'Books'),
        ('jewelry', 'Jewelry'),
    )
    
    title = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    image = models.URLField()
    rating = models.FloatField(default=4.5)
    reviews = models.IntegerField(default=0)
    discount = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title
    
    class Meta:
        ordering = ['-created_at']
```

**File: users/models.py**

```python
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    phone = models.CharField(max_length=20, blank=True)
    
    def __str__(self):
        return self.email


class Address(models.Model):
    ADDRESS_TYPE = (
        ('home', 'Home'),
        ('office', 'Office'),
    )
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='addresses')
    address_type = models.CharField(max_length=20, choices=ADDRESS_TYPE)
    street = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    is_default = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.user.email} - {self.address_type}"
```

**File: orders/models.py**

```python
from django.db import models
from products.models import Product
from users.models import CustomUser

class Order(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('shipped', 'Shipped'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    )
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='orders')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    tax = models.DecimalField(max_digits=10, decimal_places=2)
    shipping = models.DecimalField(max_digits=10, decimal_places=2)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Order {self.id} - {self.user.email}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return f"{self.order.id} - {self.product.title}"
```

---

### **Step 4: Create Serializers**

**File: products/serializers.py**

```python
from rest_framework import serializers
from .models import Product

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'title', 'price', 'description', 'category', 'image', 'rating', 'reviews', 'discount', 'created_at']
```

**File: users/serializers.py**

```python
from rest_framework import serializers
from .models import CustomUser, Address

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['id', 'address_type', 'street', 'city', 'state', 'postal_code', 'is_default']

class UserSerializer(serializers.ModelSerializer):
    addresses = AddressSerializer(many=True, read_only=True)
    
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'phone', 'addresses']

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    
    class Meta:
        model = CustomUser
        fields = ['email', 'username', 'password', 'first_name', 'last_name']
    
    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)
        return user
```

**File: orders/serializers.py**

```python
from rest_framework import serializers
from .models import Order, OrderItem
from products.serializers import ProductSerializer

class OrderItemSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    
    class Meta:
        model = OrderItem
        fields = ['id', 'product', 'quantity', 'price']

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = Order
        fields = ['id', 'user', 'status', 'subtotal', 'tax', 'shipping', 'total', 'items', 'created_at']
```

---

### **Step 5: Create Views (ViewSets)**

**File: products/views.py**

```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Product
from .serializers import ProductSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    
    def get_queryset(self):
        queryset = Product.objects.all()
        
        # Filter by category
        category = self.request.query_params.get('category')
        if category:
            queryset = queryset.filter(category=category)
        
        # Search by title or description
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search) | Q(description__icontains=search)
            )
        
        # Sort
        sort = self.request.query_params.get('sort')
        if sort == 'price-low':
            queryset = queryset.order_by('price')
        elif sort == 'price-high':
            queryset = queryset.order_by('-price')
        elif sort == 'newest':
            queryset = queryset.order_by('-created_at')
        
        return queryset
    
    @action(detail=False, methods=['get'])
    def categories(self, request):
        categories = Product.objects.values_list('category', flat=True).distinct()
        return Response(categories)
```

**File: users/views.py**

```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from .models import CustomUser, Address
from .serializers import UserSerializer, RegisterSerializer, AddressSerializer

class RegisterViewSet(viewsets.ViewSet):
    @action(detail=False, methods=['post'])
    def register(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            return Response({
                'access': str(refresh.access_token),
                'refresh': str(refresh),
                'user': UserSerializer(user).data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginViewSet(viewsets.ViewSet):
    @action(detail=False, methods=['post'])
    def login(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        
        try:
            user = CustomUser.objects.get(email=email)
            if user.check_password(password):
                refresh = RefreshToken.for_user(user)
                return Response({
                    'access': str(refresh.access_token),
                    'refresh': str(refresh),
                    'user': UserSerializer(user).data
                })
        except CustomUser.DoesNotExist:
            pass
        
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

class UserViewSet(viewsets.ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    
    @action(detail=True, methods=['post'])
    def add_address(self, request, pk=None):
        user = self.get_object()
        serializer = AddressSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
```

**File: orders/views.py**

```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Order, OrderItem
from .serializers import OrderSerializer

class OrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)
    
    def create(self, request, *args, **kwargs):
        # Create order from cart data
        cart_items = request.data.get('items', [])
        subtotal = request.data.get('subtotal')
        tax = request.data.get('tax')
        shipping = request.data.get('shipping')
        total = request.data.get('total')
        
        order = Order.objects.create(
            user=request.user,
            subtotal=subtotal,
            tax=tax,
            shipping=shipping,
            total=total,
        )
        
        # Add items to order
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                product_id=item['product_id'],
                quantity=item['quantity'],
                price=item['price']
            )
        
        return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)
```

---

### **Step 6: Create URL Routes**

**File: pocketshop/urls.py**

```python
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from products.views import ProductViewSet
from users.views import RegisterViewSet, LoginViewSet, UserViewSet
from orders.views import OrderViewSet

# Create router
router = DefaultRouter()
router.register('products', ProductViewSet, basename='product')
router.register('register', RegisterViewSet, basename='register')
router.register('login', LoginViewSet, basename='login')
router.register('users', UserViewSet, basename='user')
router.register('orders', OrderViewSet, basename='order')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/auth/', include('rest_framework.urls')),
]
```

---

### **Step 7: Run Django Migrations**

```bash
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run server
python manage.py runserver 8000
```

**Test API:** `http://localhost:8000/api/`

---

## Part 2: React Frontend Integration

### **Step 1: Create API Service**

**File: src/services/api.js**

```javascript
import axios from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      const refreshToken = localStorage.getItem('refresh_token')
      try {
        const response = await axios.post(`${API_URL}/token/refresh/`, {
          refresh: refreshToken,
        })
        localStorage.setItem('access_token', response.data.access)
        original.headers.Authorization = `Bearer ${response.data.access}`
        return api(original)
      } catch (err) {
        localStorage.clear()
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export default api
```

### **Step 2: Product Service**

**File: src/services/productService.js**

```javascript
import api from './api'

export const getProducts = async (params = {}) => {
  try {
    const response = await api.get('/products/', { params })
    return response.data
  } catch (error) {
    console.error('Error fetching products:', error)
    return []
  }
}

export const getProductById = async (id) => {
  try {
    const response = await api.get(`/products/${id}/`)
    return response.data
  } catch (error) {
    console.error('Error fetching product:', error)
    return null
  }
}

export const getCategories = async () => {
  try {
    const response = await api.get('/products/categories/')
    return response.data
  } catch (error) {
    console.error('Error fetching categories:', error)
    return []
  }
}
```

### **Step 3: Auth Service**

**File: src/services/authService.js**

```javascript
import api from './api'

export const register = async (userData) => {
  try {
    const response = await api.post('/register/register/', userData)
    if (response.data.access) {
      localStorage.setItem('access_token', response.data.access)
      localStorage.setItem('refresh_token', response.data.refresh)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  } catch (error) {
    console.error('Registration error:', error)
    return null
  }
}

export const login = async (email, password) => {
  try {
    const response = await api.post('/login/login/', { email, password })
    if (response.data.access) {
      localStorage.setItem('access_token', response.data.access)
      localStorage.setItem('refresh_token', response.data.refresh)
      localStorage.setItem('user', JSON.stringify(response.data.user))
    }
    return response.data
  } catch (error) {
    console.error('Login error:', error)
    return null
  }
}

export const logout = () => {
  localStorage.removeItem('access_token')
  localStorage.removeItem('refresh_token')
  localStorage.removeItem('user')
}

export const getCurrentUser = () => {
  const user = localStorage.getItem('user')
  return user ? JSON.parse(user) : null
}

export const isAuthenticated = () => {
  return !!localStorage.getItem('access_token')
}
```

### **Step 4: Order Service**

**File: src/services/orderService.js**

```javascript
import api from './api'

export const createOrder = async (orderData) => {
  try {
    const response = await api.post('/orders/', orderData)
    return response.data
  } catch (error) {
    console.error('Error creating order:', error)
    return null
  }
}

export const getOrders = async () => {
  try {
    const response = await api.get('/orders/')
    return response.data
  } catch (error) {
    console.error('Error fetching orders:', error)
    return []
  }
}

export const getOrderById = async (id) => {
  try {
    const response = await api.get(`/orders/${id}/`)
    return response.data
  } catch (error) {
    console.error('Error fetching order:', error)
    return null
  }
}
```

### **Step 5: Update ProductsGrid Component**

**File: src/components/ProductsGrid.jsx**

```javascript
import { useState, useEffect } from 'react'
import ProductCard from './ProductCard'
import { getProducts, getCategories } from '../services/productService'

function ProductsGrid() {
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState('featured')
  const [loading, setLoading] = useState(true)

  // Fetch products from Django
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const params = {
          category: selectedCategory !== 'all' ? selectedCategory : null,
          search: searchQuery,
          sort: sortBy,
        }
        
        const data = await getProducts(params)
        // Handle both list and paginated responses
        const productList = Array.isArray(data) ? data : data.results || []
        setProducts(productList)
        setFilteredProducts(productList)
      } catch (error) {
        console.error('Error:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [selectedCategory, searchQuery, sortBy])

  // Fetch categories
  useEffect(() => {
    const fetchCategories = async () => {
      const cats = await getCategories()
      setCategories(['all', ...cats])
    }
    fetchCategories()
  }, [])

  // Rest of component stays the same...
  return (
    // ... JSX
  )
}

export default ProductsGrid
```

### **Step 6: Create Login Component**

**File: src/pages/Login.jsx**

```javascript
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login, register } from '../services/authService'

function Login() {
  const [isLogin, setIsLogin] = useState(true)
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    username: '',
    first_name: '',
  })
  const navigate = useNavigate()

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (isLogin) {
      const result = await login(formData.email, formData.password)
      if (result) {
        navigate('/')
      } else {
        alert('Login failed')
      }
    } else {
      const result = await register(formData)
      if (result) {
        navigate('/')
      } else {
        alert('Registration failed')
      }
    }
  }

  return (
    <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px' }}>
      <h2>{isLogin ? 'Login' : 'Register'}</h2>
      
      <form onSubmit={handleSubmit}>
        {!isLogin && (
          <>
            <input
              type="text"
              name="username"
              placeholder="Username"
              value={formData.username}
              onChange={handleChange}
              required
              style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
            />
            <input
              type="text"
              name="first_name"
              placeholder="First Name"
              value={formData.first_name}
              onChange={handleChange}
              style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
            />
          </>
        )}
        
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          required
          style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
        />
        
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          required
          style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
        />
        
        <button
          type="submit"
          style={{
            width: '100%',
            padding: '10px',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
          }}
        >
          {isLogin ? 'Login' : 'Register'}
        </button>
      </form>
      
      <p style={{ textAlign: 'center', marginTop: '20px' }}>
        {isLogin ? "Don't have account?" : 'Already have account?'}
        <button
          onClick={() => setIsLogin(!isLogin)}
          style={{ background: 'none', border: 'none', color: '#3b82f6', cursor: 'pointer', marginLeft: '5px' }}
        >
          {isLogin ? 'Register' : 'Login'}
        </button>
      </p>
    </div>
  )
}

export default Login
```

---

## Environment Variables

**Frontend: .env**

```
VITE_API_URL=http://localhost:8000/api
```

**Backend: .env**

```
DEBUG=True
SECRET_KEY=your-secret-key
ALLOWED_HOSTS=localhost,127.0.0.1
DATABASE_URL=postgresql://user:password@localhost/pocketshop
CORS_ALLOWED_ORIGINS=http://localhost:5173
```

---

## Testing the Connection

### **1. Start Django Backend:**
```bash
python manage.py runserver 8000
```

### **2. Start React Frontend:**
```bash
npm run dev
```

### **3. Test API Endpoints:**

```bash
# Products
curl http://localhost:8000/api/products/

# Register
curl -X POST http://localhost:8000/api/register/register/ \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","username":"user","password":"pass123"}'

# Login
curl -X POST http://localhost:8000/api/login/login/ \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"pass123"}'
```

---

## Deployment

### **Backend (Django) - Deployment**

**Option 1: Render.com**
```bash
pip install gunicorn
pip freeze > requirements.txt
```

**Deploy with:**
- Build Command: `pip install -r requirements.txt && python manage.py migrate`
- Start Command: `gunicorn pocketshop.wsgi:application`

**Option 2: Heroku**
```bash
pip install heroku
heroku login
heroku create pocketshop-api
git push heroku main
```

### **Frontend (React) - Deployment**

**Vercel:**
```bash
npm install -g vercel
vercel
# Update API URL in .env.production
```

**Netlify:**
```bash
npm run build
# Deploy dist folder
```

---

## Project Structure

```
pocketshop-project/
├── frontend/                 (React)
│   ├── src/
│   │   ├── services/
│   │   │   ├── api.js
│   │   │   ├── productService.js
│   │   │   ├── authService.js
│   │   │   └── orderService.js
│   │   ├── components/
│   │   ├── pages/
│   │   └── App.jsx
│   └── .env
│
└── backend/                  (Django)
    ├── pocketshop/          (project settings)
    │   ├── settings.py
    │   ├── urls.py
    │   └── wsgi.py
    ├── products/            (product app)
    │   ├── models.py
    │   ├── serializers.py
    │   ├── views.py
    │   └── urls.py
    ├── users/               (user app)
    │   ├── models.py
    │   ├── serializers.py
    │   ├── views.py
    │   └── urls.py
    ├── orders/              (order app)
    │   ├── models.py
    │   ├── serializers.py
    │   ├── views.py
    │   └── urls.py
    ├── manage.py
    ├── requirements.txt
    └── .env
```

---

## Common Issues & Fixes

| Issue | Solution |
|-------|----------|
| CORS Error | Check `CORS_ALLOWED_ORIGINS` in Django settings |
| 404 API not found | Check URLs are registered in `urls.py` |
| Unauthorized 401 | Check token in localStorage, verify JWT settings |
| Database error | Run `python manage.py migrate` |
| Module not found | Install missing package: `pip install package_name` |

---

## Next Steps

✅ Set up Django backend
✅ Create models and serializers
✅ Create API viewsets and routes
✅ Connect React to Django API
✅ Implement authentication
✅ Add payment gateway
✅ Deploy frontend & backend

