# REACT + DJANGO: Advanced Topics & Deployment

## Part 3: Complete JWT Authentication System

### **Step 1: Install JWT Package**

```bash
pip install djangorestframework-simplejwt
```

### **Step 2: Complete Django JWT Setup**

**File: pocketshop/settings.py**

```python
from datetime import timedelta

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    'products',
    'users',
    'orders',
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ),
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=5),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,
}
```

### **Step 3: JWT URLs**

**File: pocketshop/urls.py**

```python
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.routers import DefaultRouter
from products.views import ProductViewSet
from users.views import UserViewSet, RegisterViewSet
from orders.views import OrderViewSet

router = DefaultRouter()
router.register('products', ProductViewSet, basename='product')
router.register('users', UserViewSet, basename='user')
router.register('orders', OrderViewSet, basename='order')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/auth/', include('rest_framework.urls')),
]
```

### **Step 4: Protected Views Example**

**File: users/views.py**

```python
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import CustomUser
from .serializers import UserSerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        # Only return current user's data
        return CustomUser.objects.filter(id=self.request.user.id)
    
    @action(detail=False, methods=['get'])
    def me(self, request):
        """Get current user profile"""
        serializer = UserSerializer(request.user)
        return Response(serializer.data)
    
    @action(detail=False, methods=['put'])
    def update_profile(self, request):
        """Update current user profile"""
        user = request.user
        user.first_name = request.data.get('first_name', user.first_name)
        user.last_name = request.data.get('last_name', user.last_name)
        user.phone = request.data.get('phone', user.phone)
        user.save()
        
        return Response({
            'message': 'Profile updated',
            'user': UserSerializer(user).data
        })
```

### **Step 5: Frontend Auth Context**

**File: src/context/AuthContext.jsx**

```javascript
import { createContext, useContext, useState, useEffect } from 'react'
import * as authService from '../services/authService'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [error, setError] = useState(null)

  // Check authentication on mount
  useEffect(() => {
    const token = localStorage.getItem('access_token')
    if (token) {
      checkAuth()
    } else {
      setLoading(false)
    }
  }, [])

  const checkAuth = async () => {
    try {
      const user = await authService.getCurrentUser()
      if (user) {
        setUser(user)
        setIsAuthenticated(true)
      }
    } catch (err) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
    } finally {
      setLoading(false)
    }
  }

  const login = async (email, password) => {
    try {
      setError(null)
      const result = await authService.login(email, password)
      if (result) {
        setUser(result.user)
        setIsAuthenticated(true)
        return true
      }
    } catch (err) {
      setError(err.message)
    }
    return false
  }

  const register = async (userData) => {
    try {
      setError(null)
      const result = await authService.register(userData)
      if (result) {
        setUser(result.user)
        setIsAuthenticated(true)
        return true
      }
    } catch (err) {
      setError(err.message)
    }
    return false
  }

  const logout = () => {
    authService.logout()
    setUser(null)
    setIsAuthenticated(false)
  }

  const value = {
    user,
    loading,
    isAuthenticated,
    error,
    login,
    register,
    logout,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider')
  }
  return context
}
```

### **Step 6: Updated Auth Service**

**File: src/services/authService.js**

```javascript
import api from './api'

export async function register(userData) {
  try {
    const response = await api.post('/users/', userData)
    if (response.data.token) {
      localStorage.setItem('access_token', response.data.token.access)
      localStorage.setItem('refresh_token', response.data.token.refresh)
    }
    return response.data
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Registration failed')
  }
}

export async function login(email, password) {
  try {
    const response = await api.post('/token/', { email, password })
    
    localStorage.setItem('access_token', response.data.access)
    localStorage.setItem('refresh_token', response.data.refresh)
    
    // Get user data
    const userResponse = await api.get('/users/me/')
    
    return {
      token: response.data,
      user: userResponse.data
    }
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Login failed')
  }
}

export async function logout() {
  localStorage.removeItem('access_token')
  localStorage.removeItem('refresh_token')
  localStorage.removeItem('user')
}

export async function getCurrentUser() {
  try {
    const response = await api.get('/users/me/')
    return response.data
  } catch (error) {
    throw new Error('Failed to get user')
  }
}

export function getToken() {
  return localStorage.getItem('access_token')
}

export function isAuthenticated() {
  return !!localStorage.getItem('access_token')
}
```

---

## Part 4: Stripe Payment Integration

### **Step 1: Backend Setup**

```bash
pip install stripe
```

**File: pocketshop/settings.py** (Add)

```python
import os
from decouple import config

STRIPE_PUBLIC_KEY = config('STRIPE_PUBLIC_KEY')
STRIPE_SECRET_KEY = config('STRIPE_SECRET_KEY')

import stripe
stripe.api_key = STRIPE_SECRET_KEY
```

### **Step 2: Payment Views**

**File: orders/views.py** (Add)

```python
import stripe
from django.conf import settings
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_payment_intent(request):
    """Create Stripe payment intent"""
    try:
        amount = int(float(request.data.get('amount', 0)) * 100)
        
        intent = stripe.PaymentIntent.create(
            amount=amount,
            currency='usd',
            metadata={
                'user_id': request.user.id,
            }
        )
        
        return Response({
            'client_secret': intent.client_secret,
            'public_key': settings.STRIPE_PUBLIC_KEY,
        })
    except Exception as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def confirm_payment(request):
    """Confirm payment and create order"""
    try:
        intent_id = request.data.get('payment_intent_id')
        intent = stripe.PaymentIntent.retrieve(intent_id)
        
        if intent.status != 'succeeded':
            return Response(
                {'error': 'Payment not completed'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create order
        order_data = {
            'user': request.user.id,
            'subtotal': request.data.get('subtotal'),
            'tax': request.data.get('tax'),
            'shipping': request.data.get('shipping'),
            'total': request.data.get('total'),
            'status': 'paid',
        }
        
        order = Order.objects.create(**order_data)
        
        # Add order items
        for item in request.data.get('items', []):
            OrderItem.objects.create(
                order=order,
                product_id=item['product_id'],
                quantity=item['quantity'],
                price=item['price']
            )
        
        return Response({
            'message': 'Payment successful',
            'order_id': order.id,
            'order': OrderSerializer(order).data
        }, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )
```

**File: orders/urls.py** (Add)

```python
from django.urls import path
from . import views

urlpatterns = [
    path('payment/create-intent/', views.create_payment_intent, name='create_intent'),
    path('payment/confirm/', views.confirm_payment, name='confirm_payment'),
]
```

### **Step 3: Frontend Stripe Setup**

```bash
npm install @stripe/react-stripe-js @stripe/js
```

**File: src/pages/Checkout.jsx**

```javascript
import { useState } from 'react'
import { loadStripe } from '@stripe/js'
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import api from '../services/api'

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)

function CheckoutForm() {
  const stripe = useStripe()
  const elements = useElements()
  const { cart } = useCart()
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const tax = subtotal * 0.18
  const shipping = subtotal > 500 ? 0 : 50
  const total = subtotal + tax + shipping

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!stripe || !elements) return

    setLoading(true)
    setError(null)

    try {
      // Create payment intent
      const intentRes = await api.post('/orders/payment/create-intent/', {
        amount: total,
      })

      // Confirm payment
      const result = await stripe.confirmCardPayment(
        intentRes.data.client_secret,
        {
          payment_method: {
            card: elements.getElement(CardElement),
            billing_details: {
              name: user.first_name + ' ' + user.last_name,
              email: user.email,
            },
          },
        }
      )

      if (result.error) {
        setError(result.error.message)
      } else if (result.paymentIntent.status === 'succeeded') {
        // Confirm order
        await api.post('/orders/payment/confirm/', {
          payment_intent_id: result.paymentIntent.id,
          items: cart,
          subtotal,
          tax,
          shipping,
          total,
        })

        alert('Payment successful!')
        // Clear cart and redirect
      }
    } catch (err) {
      setError(err.message)
    }

    setLoading(false)
  }

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: '500px', margin: '50px auto' }}>
      <h2>Checkout</h2>

      <div style={{ marginBottom: '20px', padding: '15px', background: '#f0f0f0' }}>
        <p>Subtotal: ${subtotal.toFixed(2)}</p>
        <p>Tax: ${tax.toFixed(2)}</p>
        <p>Shipping: {shipping === 0 ? 'FREE' : `$${shipping}`}</p>
        <h3>Total: ${total.toFixed(2)}</h3>
      </div>

      <CardElement />

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <button
        type="submit"
        disabled={!stripe || loading}
        style={{
          width: '100%',
          padding: '12px',
          marginTop: '20px',
          background: '#3b82f6',
          color: 'white',
          border: 'none',
          cursor: 'pointer',
        }}
      >
        {loading ? 'Processing...' : 'Pay Now'}
      </button>
    </form>
  )
}

function Checkout() {
  return (
    <Elements stripe={stripePromise}>
      <CheckoutForm />
    </Elements>
  )
}

export default Checkout
```

---

## Part 5: Testing

### **Backend Tests**

**File: products/tests.py**

```python
from django.test import TestCase
from rest_framework.test import APIClient
from .models import Product

class ProductTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.product = Product.objects.create(
            title='Test Product',
            price=99.99,
            description='Test description',
            category='electronics',
            image='http://example.com/image.jpg'
        )
    
    def test_get_products(self):
        response = self.client.get('/api/products/')
        self.assertEqual(response.status_code, 200)
    
    def test_get_product(self):
        response = self.client.get(f'/api/products/{self.product.id}/')
        self.assertEqual(response.status_code, 200)
    
    def test_create_product(self):
        data = {
            'title': 'New Product',
            'price': 49.99,
            'description': 'New description',
            'category': 'clothing',
            'image': 'http://example.com/new.jpg'
        }
        response = self.client.post('/api/products/', data)
        self.assertEqual(response.status_code, 201)
```

**Run tests:**
```bash
python manage.py test products
```

### **Frontend Tests**

**File: vitest.config.js**

```javascript
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./vitest.setup.js'],
  },
})
```

**File: src/__tests__/Auth.test.jsx**

```javascript
import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import Login from '../pages/Login'

describe('Login Component', () => {
  it('renders login form', () => {
    render(<Login />)
    expect(screen.getByPlaceholderText('Email')).toBeInTheDocument()
  })

  it('submits form with credentials', async () => {
    const { getByPlaceholderText, getByText } = render(<Login />)
    
    fireEvent.change(getByPlaceholderText('Email'), { target: { value: 'test@example.com' } })
    fireEvent.change(getByPlaceholderText('Password'), { target: { value: 'password' } })
    fireEvent.click(getByText('Login'))
    
    // Add assertions
  })
})
```

---

## Part 6: Deployment

### **Django Deployment Steps**

**1. Create requirements.txt:**

```bash
pip freeze > requirements.txt
```

**2. Render Deployment:**

Create `build.sh`:
```bash
#!/bin/bash
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
```

Create `Procfile`:
```
web: gunicorn pocketshop.wsgi
```

Environment variables on Render:
```
SECRET_KEY=your_secret_key
STRIPE_SECRET_KEY=your_stripe_key
STRIPE_PUBLIC_KEY=your_public_key
ALLOWED_HOSTS=your-app.onrender.com
DEBUG=False
```

### **React Frontend Deployment (Vercel)**

```bash
npm run build
vercel
```

**.env.production:**
```
VITE_API_URL=https://your-backend.onrender.com/api
VITE_STRIPE_PUBLIC_KEY=your_stripe_key
```

---

## Part 7: Database Optimization

```python
# settings.py - Enable Query Optimization

# Use select_related for foreign keys
# Use prefetch_related for reverse relations

# In views:
from django.db.models import Prefetch

products = Product.objects.select_related('category').prefetch_related('reviews')
```

---

## Final Checklist

✅ JWT Authentication
✅ User registration & login
✅ Protected routes
✅ Stripe payments
✅ Order management
✅ Product filtering
✅ Search functionality
✅ Admin panel
✅ Error handling
✅ Testing suite
✅ Documentation
✅ Deployment ready

**Your PocketShop is production-ready!** 🚀

