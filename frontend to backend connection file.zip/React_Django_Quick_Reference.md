# REACT + DJANGO: Quick Reference & Setup Guide

## 📚 What You Have

You now have **5 complete guides** for building PocketShop:

### **Resume/Portfolio Documents:**
1. **PocketShop_Resume_Summary.md** - Full project description for portfolio
2. **PocketShop_Resume_Bullets.md** - Bullet points for resume
3. **PocketShop_Resume_Variations.md** - Different lengths for different purposes

### **Backend Connection Guides:**
4. **Frontend_Backend_Connection_Guide.md** - Node.js/Express version
5. **Quick_Start_Backend_Connection.md** - Express quick start

### **React + Django Guides (USE THESE!):**
6. **React_Django_Complete_Guide.md** - Full Django setup & integration ⭐
7. **React_Django_Advanced_Deployment.md** - Advanced features & deployment ⭐

---

## 🚀 Quick Start (5 Steps)

### **Step 1: Create Django Backend**

```bash
# Create project folder
mkdir pocketshop-project
cd pocketshop-project

# Create backend
mkdir backend
cd backend

# Setup Python environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install Django
pip install django djangorestframework django-cors-headers

# Create project
django-admin startproject pocketshop .
python manage.py startapp products
python manage.py startapp users
python manage.py startapp orders
```

### **Step 2: Configure Django (settings.py)**

- Add apps to INSTALLED_APPS
- Add CORS settings
- Configure database
- Set up REST framework

**👉 Copy from: React_Django_Complete_Guide.md (Part 2, Step 2)**

### **Step 3: Create Models & Serializers**

- Product model (title, price, category, etc.)
- User model (email, phone, addresses)
- Order model (user, items, status, total)

**👉 Copy from: React_Django_Complete_Guide.md (Part 2, Step 3-4)**

### **Step 4: Create ViewSets & URLs**

- ProductViewSet with filter/search
- UserViewSet with auth
- OrderViewSet for orders

**👉 Copy from: React_Django_Complete_Guide.md (Part 2, Step 5-6)**

### **Step 5: Run Django**

```bash
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 8000
```

**Test:** http://localhost:8000/api/products/

---

## 🎯 Backend Architecture

```
Django Backend (localhost:8000)
│
├── Products App
│   ├── Model: Product
│   ├── Serializer: ProductSerializer
│   ├── ViewSet: ProductViewSet
│   └── Endpoints:
│       ├── GET /api/products/
│       ├── GET /api/products/:id/
│       ├── POST /api/products/
│       └── PUT/DELETE /api/products/:id/
│
├── Users App
│   ├── Model: CustomUser, Address
│   ├── Serializer: UserSerializer
│   ├── ViewSet: UserViewSet
│   └── Endpoints:
│       ├── POST /api/register/
│       ├── POST /api/token/
│       ├── GET /api/users/me/
│       └── PUT /api/users/me/
│
└── Orders App
    ├── Model: Order, OrderItem
    ├── Serializer: OrderSerializer
    ├── ViewSet: OrderViewSet
    └── Endpoints:
        ├── GET /api/orders/
        ├── POST /api/orders/
        ├── GET /api/orders/:id/
        └── POST /api/payment/confirm/
```

---

## 🔗 Frontend Connection

### **Step 1: Create API Service**

**File: src/services/api.js**

```javascript
import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api',
})

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default api
```

### **Step 2: Product Service**

```javascript
import api from './api'

export const getProducts = async (params) => {
  const res = await api.get('/products/', { params })
  return res.data
}
```

### **Step 3: Update Components**

In `ProductsGrid.jsx`, replace FakeStore API with:

```javascript
import { getProducts } from '../services/productService'

useEffect(() => {
  const fetchProducts = async () => {
    const data = await getProducts()
    setProducts(data)
  }
  fetchProducts()
}, [])
```

### **Step 4: Add Auth Context**

**File: src/context/AuthContext.jsx**

👉 Copy from: React_Django_Advanced_Deployment.md (Part 3)

### **Step 5: Set Environment Variables**

**File: .env**
```
VITE_API_URL=http://localhost:8000/api
```

---

## 🔐 Authentication Flow

```
1. User enters email & password → Frontend
2. Frontend sends → POST /api/token/
3. Django returns → access_token + refresh_token
4. Frontend stores → localStorage
5. Frontend adds token to headers → "Authorization: Bearer token"
6. All future requests authenticated ✅

Token expires → refresh_token gets new access_token
```

---

## 💳 Payment Flow (Stripe)

```
1. User clicks "Pay Now"
2. Frontend → POST /api/payment/create-intent/
3. Backend creates Stripe PaymentIntent
4. Frontend → stripe.confirmCardPayment()
5. User enters card details
6. Stripe confirms payment
7. Frontend → POST /api/payment/confirm/
8. Backend creates Order
9. Order complete ✅
```

---

## 📁 Final Project Structure

```
pocketshop-project/
│
├── frontend/                    (React)
│   ├── src/
│   │   ├── context/
│   │   │   ├── AuthContext.jsx
│   │   │   └── CartContext.jsx
│   │   ├── services/
│   │   │   ├── api.js
│   │   │   ├── authService.js
│   │   │   ├── productService.js
│   │   │   └── orderService.js
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── ProductCard.jsx
│   │   │   ├── ProductsGrid.jsx
│   │   │   ├── ProtectedRoute.jsx
│   │   │   └── Footer.jsx
│   │   ├── pages/
│   │   │   ├── Home.jsx
│   │   │   ├── Cart.jsx
│   │   │   ├── Login.jsx
│   │   │   ├── Checkout.jsx
│   │   │   ├── ProfileDashboard.jsx
│   │   │   └── ...
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── .env
│   ├── vite.config.js
│   └── package.json
│
└── backend/                     (Django)
    ├── pocketshop/              (settings)
    │   ├── settings.py
    │   ├── urls.py
    │   ├── wsgi.py
    │   └── asgi.py
    ├── products/                (app)
    │   ├── models.py
    │   ├── serializers.py
    │   ├── views.py
    │   ├── urls.py
    │   └── tests.py
    ├── users/                   (app)
    │   ├── models.py
    │   ├── serializers.py
    │   ├── views.py
    │   └── urls.py
    ├── orders/                  (app)
    │   ├── models.py
    │   ├── serializers.py
    │   ├── views.py
    │   └── urls.py
    ├── manage.py
    ├── requirements.txt
    ├── .env
    └── db.sqlite3
```

---

## ✅ Implementation Checklist

### **Backend Setup:**
- [x] Install Django & packages
- [x] Configure CORS
- [x] Create Product model
- [x] Create User model
- [x] Create Order model
- [x] Create serializers
- [x] Create viewsets
- [x] Setup JWT authentication
- [x] Configure URL routes
- [x] Test API endpoints

### **Frontend Integration:**
- [x] Create API service
- [x] Create auth service
- [x] Create auth context
- [x] Update ProductsGrid component
- [x] Add login page
- [x] Add protected routes
- [x] Add logout functionality
- [x] Add token refresh

### **Advanced Features:**
- [x] Stripe payment integration
- [x] Order management
- [x] User profiles
- [x] Address management
- [x] Wishlist system
- [x] Review system

### **Deployment:**
- [x] Prepare requirements.txt
- [x] Configure environment variables
- [x] Deploy Django to Render
- [x] Deploy React to Vercel
- [x] Set production API URL

---

## 🔧 Common Commands

### **Django:**
```bash
# Activate virtual environment
source venv/bin/activate

# Install packages
pip install -r requirements.txt

# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run server
python manage.py runserver 8000

# Run tests
python manage.py test

# Collect static files
python manage.py collectstatic
```

### **React:**
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Run tests
npm run test
```

---

## 📝 Environment Variables

**Backend: .env**
```
DEBUG=True
SECRET_KEY=your-secret-key
ALLOWED_HOSTS=localhost,127.0.0.1
DATABASE_URL=sqlite:///db.sqlite3
CORS_ALLOWED_ORIGINS=http://localhost:5173
STRIPE_PUBLIC_KEY=your_public_key
STRIPE_SECRET_KEY=your_secret_key
```

**Frontend: .env**
```
VITE_API_URL=http://localhost:8000/api
VITE_STRIPE_PUBLIC_KEY=your_public_key
```

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| CORS Error | Check CORS_ALLOWED_ORIGINS in Django settings |
| 404 API not found | Check URLs registered in Django urls.py |
| Authentication failed | Verify JWT token in localStorage |
| Database error | Run `python manage.py migrate` |
| Port already in use | Use different port: `python manage.py runserver 8001` |
| Module not found | Install missing package: `pip install package_name` |

---

## 📚 Next Steps

1. **Follow React_Django_Complete_Guide.md** - Complete setup
2. **Add JWT Authentication** - From Part 3
3. **Integrate Stripe** - From Part 4
4. **Write Tests** - From Part 5
5. **Deploy to Production** - From Part 6

---

## 🎓 Learning Resources

- **Django Docs:** https://docs.djangoproject.com/
- **Django REST:** https://www.django-rest-framework.org/
- **React Docs:** https://react.dev/
- **Stripe Docs:** https://stripe.com/docs
- **Render Deployment:** https://render.com/docs

---

## 💡 Pro Tips

1. **Use environment variables** for sensitive data
2. **Always validate** user input on frontend AND backend
3. **Use pagination** for large datasets
4. **Cache frequently accessed** data
5. **Write tests** as you build
6. **Use git** for version control
7. **Monitor errors** in production
8. **Keep API documentation** updated

---

## 🚀 You're Ready!

You have everything you need to build and deploy a production-ready e-commerce platform.

**Start with:**
1. Django backend setup ✅
2. React frontend integration ✅
3. Local testing ✅
4. Production deployment ✅

**Good luck! Happy coding!** 💻

